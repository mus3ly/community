<div class="carousel-outer">
                <div id="sync1" class="owl-carousel owl-theme">
                  <div class="item">
                      <a href="<?= $url ?>assets/images/product_image/ad(2).jpg" class="lightbox-image" data-fancybox="images" data-caption="">
                        <img src="<?= $url ?>assets/images/product_image/ad(2).jpg" alt="">
                      </a>
                  </div>
                  <div class="item">
                      <a href="<?= $url ?>assets/images/product_image/ad(4).jpg" class="lightbox-image" data-fancybox="images" data-caption="">
                        <img src="<?= $url ?>assets/images/product_image/ad(4).jpg" alt="">
                      </a>
                  </div>
                  <div class="item">
                      <a href="<?= $url ?>assets/images/product_image/ad(5).jpg" class="lightbox-image" data-fancybox="images" data-caption="">
                        <img src="<?= $url ?>assets/images/product_image/ad(5).jpg" alt="">
                      </a>
                  </div>
                  <div class="item">
                      <a href="<?= $url ?>assets/images/product_image/ad(6).jpg" class="lightbox-image" data-fancybox="images" data-caption="">
                        <img src="<?= $url ?>assets/images/product_image/ad(6).jpg" alt="">
                      </a>
                  </div>
                  <div class="item">
                    <a href="<?= $url ?>assets/images/product_image/ad(7).jpg" class="lightbox-image" data-fancybox="images" data-caption="">
                      <img src="<?= $url ?>assets/images/product_image/ad(7).jpg" alt="">
                    </a>
                </div>
                </div>
                
                <div id="sync2"  class="owl-carousel owl-theme">
                  <div class="item">
                      <img src="<?= $url ?>assets/images/product_image/ad(2).jpg" alt="">
                  </div>
                  <div class="item">
                    <img src="<?= $url ?>assets/images/product_image/ad(4).jpg" alt="">
                  </div>
                  <div class="item">
                    <img src="<?= $url ?>assets/images/product_image/ad(5).jpg" alt="">
                  </div>
                  <div class="item">
                    <img src="<?= $url ?>assets/images/product_image/ad(6).jpg" alt="">
                  </div>
                  <div class="item">
                    <img src="<?= $url ?>assets/images/product_image/ad(7).jpg" alt="">
                </div>
                </div>
              </div>